import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Fungsi untuk mengirim email via kirim.email
async function sendEmail({
  to,
  subject,
  html,
  replyTo
}: {
  to: string
  subject: string
  html: string
  replyTo?: string
}) {
  const apiKey = process.env.KIRIM_EMAIL_API_KEY
  const fromEmail = process.env.FROM_EMAIL || 'noreply@yourdomain.com'
  const fromName = process.env.FROM_NAME || 'STIFIn Indonesia'

  try {
    const response = await fetch('https://api.kirim.email/v1/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        sender: {
          email: fromEmail,
          name: fromName
        },
        recipient: {
          email: to
        },
        subject: subject,
        content: {
          type: 'html',
          value: html
        },
        reply_to: replyTo || fromEmail
      })
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw new Error(`kirim.email API error: ${response.status} - ${JSON.stringify(errorData)}`)
    }

    const result = await response.json()
    console.log('Email sent successfully via kirim.email:', result)
    return result
  } catch (error) {
    console.error('Error sending email via kirim.email:', error)
    throw error
  }
}

// Email template untuk admin notification
const getAdminEmailHTML = (data: { name: string; email: string; whatsapp: string; childAge: string; createdAt: Date }) => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #f97316, #fbbf24); padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
    .header h1 { color: white; margin: 0; font-size: 28px; }
    .content { background: #fff7ed; padding: 30px; border-radius: 0 0 10px 10px; }
    .data-point { background: white; padding: 15px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #f97316; }
    .data-point strong { color: #f97316; }
    .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
    .cta-button { display: inline-block; background: #f97316; color: white; padding: 12px 30px; text-decoration: none; border-radius: 8px; margin: 20px 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🎉 Lead Baru Diterima!</h1>
    </div>
    <div class="content">
      <p>Anda mendapatkan lead baru dari landing page Tes STIFIn. Berikut detailnya:</p>
      
      <div class="data-point">
        <strong>Nama Lengkap:</strong> ${data.name}
      </div>
      
      <div class="data-point">
        <strong>Email:</strong> ${data.email}
      </div>
      
      <div class="data-point">
        <strong>No. WhatsApp:</strong> ${data.whatsapp}
      </div>
      
      <div class="data-point">
        <strong>Usia Anak:</strong> ${data.childAge}
      </div>
      
      <div class="data-point">
        <strong>Waktu Submit:</strong> ${new Date(data.createdAt).toLocaleString('id-ID')}
      </div>
      
      <div style="text-align: center;">
        <a href="https://wa.me/${data.whatsapp.replace(/[^0-9]/g, '')}" class="cta-button">
          📱 Hubungi via WhatsApp
        </a>
      </div>
      
      <p style="margin-top: 20px; color: #666;">
        <strong>Apa selanjutnya?</strong><br>
        1. Hubungi lead dalam 24 jam<br>
        2. Kirim checklist yang diminta<br>
        3. Jelaskan lebih lanjut tentang tes STIFIn
      </p>
    </div>
    <div class="footer">
      <p>Email ini dikirim secara otomatis dari landing page Tes STIFIn</p>
      <p>${new Date().toLocaleString('id-ID')}</p>
    </div>
  </div>
</body>
</html>
`

// Email template untuk user confirmation
const getUserEmailHTML = (name: string) => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #f97316, #fbbf24); padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
    .header h1 { color: white; margin: 0; font-size: 28px; }
    .content { background: #fff7ed; padding: 30px; border-radius: 0 0 10px 10px; }
    .checklist-item { background: white; padding: 15px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #22c55e; }
    .checklist-item strong { color: #22c55e; }
    .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>✅ Terima Kasih, ${name}!</h1>
    </div>
    <div class="content">
      <p>Terima kasih telah mengisi form di landing page Tes STIFIn. Kami sangat senang bisa membantu Anda memahami potensi anak.</p>
      
      <h2 style="color: #f97316; margin-top: 30px;">📋 Checklist Pemilihan Sekolah Sesuai Potensi Anak</h2>
      
      <div class="checklist-item">
        <strong>1.</strong> Identifikasi cara belajar anak (visual, auditori, atau kinestetik)
      </div>
      
      <div class="checklist-item">
        <strong>2.</strong> Perhatikan aktivitas yang membuat anak antusias dan tidak cepat bosan
      </div>
      
      <div class="checklist-item">
        <strong>3.</strong> Cek kurikulum dan metode pengajaran sekolah yang dituju
      </div>
      
      <div class="checklist-item">
        <strong>4.</strong> Pertimbangkan fasilitas yang mendukung gaya belajar anak
      </div>
      
      <div class="checklist-item">
        <strong>5.</strong> Diskusikan dengan anak tentang preferensi mereka
      </div>
      
      <div class="checklist-item">
        <strong>6.</strong> Lakukan tes STIFIn untuk memahami potensi genetik anak
      </div>
      
      <h2 style="color: #f97316; margin-top: 30px;">🎯 Apa Selanjutnya?</h2>
      
      <p>Tim kami akan segera menghubungi Anda untuk:</p>
      <ul>
        <li>Menjelaskan lebih detail tentang tes STIFIn</li>
        <li>Membantu Anda memahami hasil tes</li>
        <li>Memberikan rekomendasi yang tepat untuk anak</li>
      </ul>
      
      <p style="margin-top: 20px; color: #666;">
        Jika ada pertanyaan, jangan ragu untuk menghubungi kami.
      </p>
    </div>
    <div class="footer">
      <p>Tes Karakter Genetik STIFIn</p>
      <p>Membantu orang tua memahami potensi anak untuk pilihan pendidikan yang lebih tepat</p>
    </div>
  </div>
</body>
</html>
`

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, whatsapp, childAge } = body

    // Validasi input
    if (!name || !email || !whatsapp || !childAge) {
      return NextResponse.json(
        { error: 'Semua field harus diisi' },
        { status: 400 }
      )
    }

    // Validasi email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Format email tidak valid' },
        { status: 400 }
      )
    }

    // Validasi whatsapp (hanya angka)
    const phoneRegex = /^[0-9]+$/
    if (!phoneRegex.test(whatsapp.replace(/[^0-9]/g, ''))) {
      return NextResponse.json(
        { error: 'Format nomor WhatsApp tidak valid' },
        { status: 400 }
      )
    }

    // Simpan lead ke database
    const lead = await db.lead.create({
      data: {
        name,
        email,
        whatsapp,
        childAge
      }
    })

    // Kirim email ke admin (notification lead baru)
    try {
      await sendEmail({
        to: process.env.ADMIN_EMAIL || 'admin@example.com',
        subject: `🎉 Lead Baru: ${name} - Tes STIFIn`,
        html: getAdminEmailHTML({
          name,
          email,
          whatsapp,
          childAge,
          createdAt: lead.createdAt
        })
      })
    } catch (emailError) {
      console.error('Gagal mengirim email admin:', emailError)
      // Tetap lanjut, jangan gagalkan request jika email gagal
    }

    // Kirim email konfirmasi ke user
    try {
      await sendEmail({
        to: email,
        subject: '✅ Checklist Pemilihan Sekolah Sesuai Potensi Anak',
        html: getUserEmailHTML(name),
        replyTo: process.env.ADMIN_EMAIL
      })
    } catch (emailError) {
      console.error('Gagal mengirim email konfirmasi:', emailError)
      // Tetap lanjut, jangan gagalkan request jika email gagal
    }

    return NextResponse.json(
      { 
        success: true, 
        message: 'Lead berhasil disimpan',
        data: lead
      },
      { status: 201 }
    )

  } catch (error) {
    console.error('Error creating lead:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menyimpan data' },
      { status: 500 }
    )
  }
}

export async function GET() {
  try {
    const leads = await db.lead.findMany({
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(
      { success: true, data: leads },
      { status: 200 }
    )
  } catch (error) {
    console.error('Error fetching leads:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data' },
      { status: 500 }
    )
  }
}
