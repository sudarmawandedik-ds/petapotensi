'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { CheckCircle2, Brain, GraduationCap, Heart, Target, Lightbulb, ArrowRight } from 'lucide-react'

export default function Home() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    whatsapp: '',
    childAge: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const response = await fetch('/api/lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      })

      if (response.ok) {
        setShowSuccess(true)
      }
    } catch (error) {
      console.error('Error submitting form:', error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-amber-50 to-orange-50">
      {/* Hero Section - PAIN */}
      <header className="py-8 md:py-12 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-orange-100 text-orange-700 px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Brain className="w-4 h-4" />
            <span>Metode Berbasis Riset Genetik</span>
          </div>
          
          <h1 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">
            Apakah Anda Pernah Berpikir...
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-700 mb-4 leading-relaxed">
            "Apakah minat anak saya sudah sejalan dengan pilihan sekolahnya?"
          </p>
          
          <p className="text-lg text-gray-600 leading-relaxed">
            Sebagai orang tua, kita tentu ingin anak tumbuh di lingkungan yang tepat. 
            Tapi bagaimana jika pilihan yang kita buat hari ini ternyata tidak sesuai dengan 
            potensi asli mereka?
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-4 pb-16">
        <div className="max-w-2xl mx-auto space-y-12">
          
          {/* Pain Points */}
          <section>
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-8 text-center">
              Situasi yang Mungkin Pernah Anda Rasakan
            </h2>
            
            <div className="space-y-6">
              {[
                {
                  icon: <GraduationCap className="w-6 h-6" />,
                  title: "Anak Sering Merasa Bosan di Sekolah",
                  description: "Mereka kehilangan semangat belajar, padahal dulu sangat antusias. Apakah pilihan sekolahnya kurang tepat?"
                },
                {
                  icon: <Heart className="w-6 h-6" />,
                  title: "Melihat Anak Tidak Menikmati Kegiatan Ekstrakurikuler",
                  description: "Anda sudah mencoba berbagai aktivitas, tapi belum menemukan yang benar-benar membuatnya bersinar."
                },
                {
                  icon: <Target className="w-6 h-6" />,
                  title: "Bingung Memilih Jenjang Pendidikan Berikutnya",
                  description: "SMA IPA, IPS, atau jurusan vokasi? Keputusan ini terasa berat karena takut salah pilih."
                }
              ].map((item, index) => (
                <Card key={index} className="p-6 border-2 border-orange-200 hover:border-orange-300 transition-colors">
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center text-orange-600">
                      {item.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg text-gray-900 mb-2">
                        {item.title}
                      </h3>
                      <p className="text-gray-600 leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </section>

          {/* Agitate Section */}
          <section className="bg-white rounded-2xl p-8 shadow-lg border border-orange-100">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6 text-center">
              Mengapa Ini Penting untuk Dipahami?
            </h2>
            
            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                <strong className="text-gray-900">Setiap anak memiliki cara belajar yang berbeda.</strong> 
                Ada yang visual (lebih mudah paham dengan gambar), ada yang auditori (lebih nyaman dengan suara), 
                dan ada yang kinestetik (belajar sambil bergerak).
              </p>
              
              <p>
                Ketika lingkungan belajar tidak sesuai dengan cara kerja otak anak, mereka bisa:
              </p>
              
              <ul className="space-y-3 ml-4">
                {[
                  "Kehilangan rasa percaya diri karena merasa 'kurang pintar'",
                  "Merasa tertekan dan stres dalam kegiatan sehari-hari",
                  "Tidak menemukan passion yang sebenarnya",
                  "Memiliki potensi yang belum tergali sepenuhnya"
                ].map((item, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-red-600 text-sm font-bold">{index + 1}</span>
                    </div>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              
              <p className="pt-4 border-t border-gray-200">
                <strong className="text-gray-900">Bayangkan jika kita bisa mengenali potensi ini sejak dini.</strong> 
                Bukan untuk memaksa anak mengikuti arah tertentu, tapi untuk memberikan lingkungan 
                yang mendukung mereka tumbuh optimal.
              </p>
            </div>
          </section>

          {/* Solution Section */}
          <section>
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
                <Lightbulb className="w-4 h-4" />
                <span>Solusi yang Bisa Membantu</span>
              </div>
              
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Kenali Potensi Genetik Anak dengan Tes STIFIn
              </h2>
              
              <p className="text-lg text-gray-600 max-w-xl mx-auto">
                STIFIn adalah metode analisis sidik jari yang membantu mengenali 
                kecenderungan cara kerja otak seseorang.
              </p>
            </div>

            {/* What is STIFIn */}
            <Card className="p-8 mb-8 bg-gradient-to-br from-orange-50 to-amber-50 border-2 border-orange-200">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Apa yang Akan Anda Dapatkan?</h3>
              
              <div className="space-y-4">
                {[
                  {
                    title: "Laporan Analisis Lengkap",
                    desc: "Dokumen yang menjelaskan kecenderungan cara kerja otak anak"
                  },
                  {
                    title: "Rekomendasi Metode Belajar",
                    desc: "Saran pendekatan belajar yang lebih sesuai dengan karakter anak"
                  },
                  {
                    title: "Panduan Memilih Jenjang Sekolah",
                    desc: "Pertimbangan berdasarkan potensi yang teridentifikasi"
                  },
                  {
                    title: "Konsultasi Hasil Tes",
                    desc: "Penjelasan detail dan diskusi untuk menjawab pertanyaan Anda"
                  }
                ].map((item, index) => (
                  <div key={index} className="flex gap-3 items-start">
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-gray-900">{item.title}</p>
                      <p className="text-gray-600 text-sm">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* How It Works */}
            <Card className="p-8 mb-8">
              <h3 className="text-xl font-bold text-gray-900 mb-6 text-center">Cara Kerjanya Sederhana</h3>
              
              <div className="grid md:grid-cols-3 gap-6">
                {[
                  {
                    step: "1",
                    title: "Ambil Sidik Jari",
                    desc: "Proses cepat dan nyaman, tidak menyakitkan sama sekali"
                  },
                  {
                    step: "2",
                    title: "Analisis oleh Ahli",
                    desc: "Tim kami akan menganalisis pola sidik jari dengan teliti"
                  },
                  {
                    step: "3",
                    title: "Terima Laporan",
                    desc: "Dapatkan hasil lengkap beserta rekomendasi yang bisa diaplikasikan"
                  }
                ].map((item, index) => (
                  <div key={index} className="text-center">
                    <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center text-orange-600 font-bold text-xl mb-4 mx-auto">
                      {item.step}
                    </div>
                    <h4 className="font-semibold text-gray-900 mb-2">{item.title}</h4>
                    <p className="text-gray-600 text-sm">{item.desc}</p>
                  </div>
                ))}
              </div>
            </Card>

            {/* Pricing */}
            <Card className="p-8 bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200">
              <div className="text-center mb-6">
                <p className="text-gray-600 mb-2">Investasi untuk Masa Depan Anak</p>
                <div className="flex items-center justify-center gap-3">
                  <span className="text-gray-400 line-through text-lg">Rp 750.000</span>
                  <span className="text-4xl font-bold text-green-700">Rp 650.000</span>
                </div>
                <p className="text-sm text-green-600 mt-2 font-medium">Harga promo terbatas</p>
              </div>
            </Card>
          </section>

          {/* CTA Form */}
          <section className="bg-white rounded-2xl p-8 shadow-xl border-2 border-orange-300">
            <div className="text-center mb-6">
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-3">
                Dapatkan Checklist Pemilihan Sekolah Sesuai Potensi Anak
              </h2>
              <p className="text-gray-600">
                Isi form di bawah ini untuk mendapatkan panduan gratis dan info lebih lanjut tentang tes STIFIn
              </p>
            </div>

            {showSuccess ? (
              <Card className="p-8 bg-green-50 border-2 border-green-200 text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Terima Kasih!</h3>
                <p className="text-gray-600">
                  Kami telah mengirimkan checklist ke email Anda. Tim kami akan segera menghubungi 
                  untuk memberikan informasi lebih lanjut tentang tes STIFIn.
                </p>
              </Card>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                    Nama Lengkap
                  </label>
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    required
                    placeholder="Masukkan nama lengkap Anda"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full h-12 text-base"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    Email
                  </label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    required
                    placeholder="nama@email.com"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full h-12 text-base"
                  />
                </div>

                <div>
                  <label htmlFor="whatsapp" className="block text-sm font-medium text-gray-700 mb-2">
                    No. WhatsApp
                  </label>
                  <Input
                    id="whatsapp"
                    name="whatsapp"
                    type="tel"
                    required
                    placeholder="08xxxxxxxxxx"
                    value={formData.whatsapp}
                    onChange={handleInputChange}
                    className="w-full h-12 text-base"
                  />
                </div>

                <div>
                  <label htmlFor="childAge" className="block text-sm font-medium text-gray-700 mb-2">
                    Usia Anak
                  </label>
                  <Input
                    id="childAge"
                    name="childAge"
                    type="text"
                    required
                    placeholder="Contoh: 12 tahun"
                    value={formData.childAge}
                    onChange={handleInputChange}
                    className="w-full h-12 text-base"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full h-14 text-lg font-semibold bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white"
                >
                  {isSubmitting ? (
                    'Mengirim...'
                  ) : (
                    <>
                      Dapatkan Checklist
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </>
                  )}
                </Button>

                <p className="text-xs text-gray-500 text-center">
                  Dengan mengisi form ini, Anda setuju untuk dihubungi oleh tim kami mengenai 
                  informasi tes STIFIn. Data Anda aman dan tidak akan dibagikan ke pihak lain.
                </p>
              </form>
            )}
          </section>

          {/* FAQ */}
          <section>
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-8 text-center">
              Pertanyaan yang Sering Diajukan
            </h2>
            
            <div className="space-y-4">
              {[
                {
                  q: "Apakah tes ini menyakitkan?",
                  a: "Tidak sama sekali. Proses pengambilan sidik jari sangat cepat, mudah, dan nyaman dilakukan."
                },
                {
                  q: "Berapa lama hasilnya keluar?",
                  a: "Hasil analisis biasanya siap dalam 3-5 hari kerja setelah pengambilan sidik jari."
                },
                {
                  q: "Apakah hasil tes bisa berubah seiring waktu?",
                  a: "Polgenetik yang dianalisis bersifat permanen, sehingga hasilnya tetap konsisten sepanjang hidup."
                },
                {
                  q: "Apakah tes ini menentukan bakat anak?",
                  a: "Tes ini membantu mengenali cara kerja otak dan kecenderungan belajar. Bakat masih perlu dikembangkan melalui latihan dan pengalaman."
                }
              ].map((item, index) => (
                <Card key={index} className="p-6">
                  <h3 className="font-semibold text-gray-900 mb-2">{item.q}</h3>
                  <p className="text-gray-600">{item.a}</p>
                </Card>
              ))}
            </div>
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-8 px-4 mt-auto">
        <div className="max-w-3xl mx-auto text-center">
          <p className="mb-2">
            <strong className="text-white">Tes Karakter Genetik STIFIn</strong>
          </p>
          <p className="text-sm">
            Membantu orang tua memahami potensi anak untuk pilihan pendidikan yang lebih tepat
          </p>
          <p className="text-xs text-gray-500 mt-4">
            © 2024 STIFIn Indonesia. Semua hak dilindungi.
          </p>
        </div>
      </footer>
    </div>
  )
}
